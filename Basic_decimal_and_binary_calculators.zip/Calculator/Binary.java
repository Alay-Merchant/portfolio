import java.util.Scanner;

public class Binary {
	public static void main(String args[]){
		int number;

		Scanner in = new Scanner(System.in);

		System.out.println("Enter the (+ve) number to be converted: ");
		number = in.nextInt();
		System.out.println(" "+binaryform(number));
	}
//hexadecimal function below
public static String decToHex(int number)
  {
        return Integer.toHexString(number);
  }
//end of hexadecimal function
private static Object binaryform(int number){
	int remainder;

	if (number <= 1){
		System.out.print(number);
		return number;
	}
	remainder = number % 2;
	binaryform(number >> 1);
	System.out.print(remainder);
	{
		return("end");
	}
}
}