import java.util.Scanner;

public class Decimal{
	public static void main( String args[]){
		double n1;
		double n2;
		String operation;
		String converterType;

		Scanner in = new Scanner(System.in);
		System.out.println("Enter first number(for simple calculations): ");
		n1 = in.nextDouble();
		System.out.println("Enter second number(for simple calculations): ");
		n2 = in.nextDouble();

		Scanner op = new Scanner(System.in);
		System.out.println("Enter your operation('converter' for Binary or Hexadecimal conversions): ");
		operation = op.next();

		switch (operation){
			case "+":
			System.out.println("Answer: " + (n1 + n2));
			break;
			case "-":
			System.out.println("Answer: " + (n1 - n2));
			break;
			case "*":
			System.out.println("Answer: " + (n1 * n2));
			break;
			case "/":
			System.out.println("Answer: " + (n1 / n2));
			break;
			case "mod":
			System.out.println("Answer: " + (n1 % n2));
			
			case "converter":
			Scanner con = new Scanner(System.in);
			System.out.println("What kind? ");
			converterType = con.next();
				switch (converterType){
				case "Binary":
				Binary.main(args);
				break;
				case "Hexadecimal":
				Scanner numb = new Scanner(System.in);
				System.out.println("Enter a number: ");
				int number = numb.nextInt();
				System.out.println("Hexadecimal: '" + Binary.decToHex(number) + "' end");
			}
			break;
		}
		}


	}
