import java.util.*;
import java.io.*;

public class Blackjack{

	public static void main( String args[] ){

		System.out.println("Welcome to Blackjack!");
		Deck playingDeck = new Deck();
		playingDeck.createFullDeck();
		playingDeck.shuffle();
		
		Deck playerDeck = new Deck();
		
		Deck dealerDeck = new Deck();

		double playerMoney = 100.00;

		Scanner userInput = new Scanner(System.in);

		//Game Loop
		while(playerMoney > 0 ){
			System.out.println("You have $" + playerMoney + ", how much will you bet?");
			double playerBet = userInput.nextDouble();
			if (playerBet > playerMoney){
				System.out.println("You cannot bet more than you have. GET OUT!");
				break;
			}

			boolean endRound = false;
			playerDeck.draw(playingDeck);
			playerDeck.draw(playingDeck);

			dealerDeck.draw(playingDeck);
			dealerDeck.draw(playingDeck);

			while(true){
				System.out.println("Your hand: ");
				System.out.println(playerDeck.toString());
				System.out.println("Your deck is valued at: " + playerDeck.cardsvalue());
				
				System.out.println("Dealer hand: " + dealerDeck.getCard(0).toString() + " and [HIDDEN].");

				System.out.println("Would you like to (1)HIT or (2)STAND?");
				int response = userInput.nextInt();

				if (response == 1){
					playerDeck.draw(playingDeck);
					System.out.println("Your drew a: " + playerDeck.getCard(playerDeck.deckSize()-1).toString());
					
					if(playerDeck.cardsvalue() > 21){
						System.out.println("Bust! Card value at: "+ playerDeck.cardsvalue());
						playerMoney -= playerBet;
						endRound = true;
						break;
					}

				}
				if (response == 2){
					break;
				}
			}	

			System.out.println("Dealer cards: " + dealerDeck.toString());

			if((dealerDeck.cardsvalue() > playerDeck.cardsvalue())&& (endRound == false)){
				System.out.println("DEALER WON!");
				playerMoney -= playerBet;
				endRound = true;
			}
			while((dealerDeck.cardsvalue() < 17)&& (endRound == false)){
				dealerDeck.draw(playingDeck);
				System.out.println("Dealer draws: " + dealerDeck.getCard(dealerDeck.deckSize()-1).toString());
			}
			System.out.println("Dealer's hand is valued at: " + dealerDeck.cardsvalue());
			if ((dealerDeck.cardsvalue() > 21)&& endRound == false){
				System.out.println("Dealer busts! You win");
				playerMoney += playerBet;
				endRound = true;
			}
			if((playerDeck.cardsvalue() == dealerDeck.cardsvalue())&& endRound == false){
				System.out.println("Push");
				endRound = true;
			}
			if ((playerDeck.cardsvalue() > dealerDeck.cardsvalue())&& endRound == false){
				System.out.println("You win the hand!");
				playerMoney += playerBet;
				endRound = true;
			}

			else if (endRound == false){
				System.out.println("You lost the hand!");
				playerMoney -= playerBet;
				endRound = true;
			}

			playerDeck.moveAllToDeck(playingDeck);
			dealerDeck.moveAllToDeck(playingDeck);
			System.out.println("End of hand.");
		}
		System.out.println("Game Over. You are out of money! :'( ");

	}
}