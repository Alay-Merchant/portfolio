public enum Suit {
	CLUBS, DIAMONDS, SPADES, HEARTS
}