import java.util.*;
public class leaderboard{

public void makefile{
PrintWriter writer = new PrintWriter("leaderboard.txt", "UTF-8");
writer.close();
}



