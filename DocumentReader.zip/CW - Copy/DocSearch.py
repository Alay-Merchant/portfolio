#Student number - 1769422
#ignore the comments for number input a, as the previous version took a number input but this one doesnt. 
import math
import numpy as np

#a = input("Enter file name: ")
#line_list = list(open(("set" + str(a) + "/docs.txt"), 'r'))
line_list = list(open(("docs.txt"), 'r'))
count = 1
inverted_index  = dict()
for doc in line_list:
	for word in doc.split():
		if word not in inverted_index:
			inverted_index.setdefault(word, set((str(count))))
		else:
			inverted_index[word].add(str(count))
	count += 1
#needs to go in list as below, as inverted_index.keys() cannot be referenced on it's own
single_word_list = list(inverted_index.keys())

def VectorBuild(d):
	v = []
	key = d.split()
	for x in range(len(single_word_list)):
		v.append(0)
		for i in range(len(key)):
			if key[i] == single_word_list[x]:
				v[x] += 1

	return v

#used the calculation below from an example in the lectures. Reference: Document matching python demo example.
def CalculateAngle(x,y):
    norm_x = np.linalg.norm(x)
    norm_y = np.linalg.norm(y)
    cos_theta = np.dot(x, y) / (norm_x * norm_y)
    theta = math.degrees(math.acos(cos_theta))
    return theta

def readDocs():#a):
	#open file and create dictionary-------------------------------------
	#lines = list(open(("set" + str(a) + "/docs.txt"), 'r'))
	lines = list(open(("docs.txt"), 'r'))
	doc_dict = dict()
	#queries = list(open("set" + str(a) + "/queries.txt"))
	queries = list(open("queries.txt"))
	for doc in lines:
		for word in doc.split():
			if word not in doc_dict:
				doc_dict.setdefault(word, 1)
			else:
				doc_dict[word] += 1
	print("Words in dictionary: ", len(doc_dict))
	#inverted index-------------------------------------------------------
	count = 1
	inverted_index  = dict()
	for doc in lines:
		for word in doc.split():
			if word not in inverted_index:
				inverted_index.setdefault(word, set((str(count))))
			else:
				inverted_index[word].add(str(count))
		count += 1	
	#print query and relevent documents-----------------------------------
	for q in queries:
		print("Query: ", q.rstrip("\n"))
		relevent_documents = []
		for word in q.split():
			if word in inverted_index:
				relevent_documents.append(set(inverted_index[word]))
		relevent = set.intersection(*relevent_documents)
		print("Relevent documents: ", ' '.join(str(doc_num) for doc_num in relevent))
	#vector calculations called-------------------------------------------	
		angles = []
		d = {}
		b = 0
		relevent_list = list()
		for x in relevent:
			VectorA = VectorBuild(q)
			relevent_list = list(sorted(relevent))
			VectorB = VectorBuild(lines[int(x)-1])
			angle = CalculateAngle(VectorA, VectorB)
			angles.append(angle)
			d[angle] = x
			#print("VectorA",VectorA,"VectorB",VectorB)
		for b in range(len(angles)):
			angles.sort()
			print(d[angles[b]], round(angles[b],2))

readDocs()#a)