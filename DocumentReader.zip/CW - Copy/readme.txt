This was part of a coursework, where I used python to read documents 
and process information which was necessary for the task set.
You need to change the docs/queries.txt files when running as this is was a necessary part of the marking process and 
was not allowed to be automated by taking an input.