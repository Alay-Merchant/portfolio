This is my part of a project I did where we made a desktop app in java,
 and I created a system for 'the schools' which were going to come to do our quiz, to enter their information