public class showmatrix{
	public static void main(String [] args) { 
		//take the input n
		String numberinput = args[0];
		int n = Integer.parseInt(numberinput);
		//int x = 1, y =((n+1) / 2);
		int x = 0, y =((n+1) / 2)-1;

		//create the matrix of 0's
		int[][] matrix = new int[n][n];
		for (int i = 0; i < n; i++) { 
			for (int j = 0; j < n; j++) { 
				matrix[i][j] = 0;
				//System.out.print(matrix[i][j] + " ");
			}
			//System.out.println(" ");
		}
		matrix[x][y] = 1;
		//algorithm
		for (int i = 2; i <= Math.pow(n,2); i++){
			if ((x == 0) && (y == 0)){
				x = 2;
				y = 1;
			}
			else{
				if(x <= 0){
					x = n;
				}

				if(y <= 0){
					y = n;
				}
			}
			if (matrix[x-1][y-1] == 0){
				x--;
				y--;
			}
			else{
					x++;
			}
		
		matrix[x][y] = i;
		}
	for (int i = 0; i < n; i++) { 
			for (int j = 0; j < n; j++) { 
				System.out.print(matrix[i][j] + " ");
			}
			System.out.println(" ");
		}

  }
}


