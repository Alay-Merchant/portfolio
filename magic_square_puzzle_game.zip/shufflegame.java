import java.util.*;
public class shufflegame extends showmatrix{
	public static void main(String args[]){
		int[][] matrix = matrixcreate();
		int n = matrix.length;
		int total = 0;
		Scanner in = new Scanner(System.in);
		boolean won = false;
		int move_count = 0;

		shuffle(matrix, new Random(),n);
		System.out.println("---------------------------");
		System.out.println("Shuffled square: ");
		for(int i = 0; i < n;i++){
			for(int j = 0; j < n;j++){
				System.out.print(matrix[i][j] + " ");
			}
			System.out.println(" ");
		}
		while (won == false){
		System.out.println("Enter the i(how many across starting from top left), j(how many down starting from top left) and direction(U,D,L,R): ");
		System.out.println("i,j,direction(U,D,L,R): ");
		String input = in.nextLine();
		String[] broken_input = input.split(" "); //has to use spaces to seperate the single line input
		int j = Integer.parseInt(broken_input[0]);
		int i = Integer.parseInt(broken_input[1]);
		String dir = broken_input[2];
		System.out.println("--------------------");
		if(!((i < n)||(i > 0))){
			System.out.println("The i value is out of range!");
		}
		else if ((!((j < n)||(j > 0)))){
			System.out.println("The j value if out of range!");
		}
		else{ //i = row, j = column
			if(dir.equals("U")){
				move_count ++;
				int a = matrix[i-1][j-1];
				int b = matrix[i-2][j-1];
				matrix[i-1][j-1] = b;
				matrix[i-2][j-1] = a;
			}
			else if(dir.equals("D")){
				move_count ++;
				int a = matrix[i-1][j-1];
				int b = matrix[i][j-1];
				matrix[i-1][j-1] = b;
				matrix[i][j-1] = a;
			}
			else if(dir.equals("L")){
				move_count ++;
				int a = matrix[i-1][j-1];
				int b = matrix[i-1][j-2];
				matrix[i-1][j-2]  = a;
				matrix[i-1][j-1] = b;
				}
			else if(dir.equals("R")){
				move_count ++;
				int a = matrix[i-1][j-1];
				int b = matrix[i-1][j];
				matrix[i-1][j]  = a;
				matrix[i-1][j-1] = b;
			}
				for(int a = 0; a < n;a++){
					for(int b = 0; b < n;b++){
						System.out.print(matrix[a][b] + " ");
						}
					System.out.println(" ");
					}
			}
		int[] colSum = new int[n];
		int[] rowSum = new int[n];
		boolean colEqual = false;
		boolean rowEqual = false;
		for(int q=0; q < n;q++){
			for (int w = 0; w < n; w++){
				rowSum[q] += matrix[q][w];
				colSum[w] += matrix[q][w];
			int firstcol = colSum[0];
			for (int x : colSum){
				if (x == firstcol){
					if (x == ((n*((n*n)+1))/2)){
						colEqual = true;
					}
					else{
						colEqual = false;
					}
				}else{
					colEqual = false;
				}
			}
			int firstrow = rowSum[0];
			for (int x : rowSum){
				if (x == firstrow){
					if (x == ((n*((n*n)+1))/2)){
						rowEqual = true;
				} else{
					rowEqual = false;
				}
				} else{
					rowEqual = false;
				}
			}
			if ((rowEqual == true) && (colEqual==true)){
				won = true;
				System.out.println("Moves: "+move_count+ ", you won!");
			}
			}
			
		}
		}

	}

	public static void shuffle(int[][] matrix, Random random, int n){
		for (int x = (n*n); x > 1; x--){ 
			int j = random.nextInt(x);
			swap_for_shuffle(matrix, n, x-1, j);
		}
	}

	public static void swap_for_shuffle(int[][] matrix, int n, int i, int j){
		int store = matrix[i/n][i%n];
		matrix[i/n][i%n] = matrix[j/n][j%n]; //found this way to swap one position in the square for another one.
		matrix[j/n][j%n] = store;			
	}

	
	public static int[][] matrixcreate(){
		//take the input n
		Scanner num = new Scanner(System.in);
		System.out.println("You are playing a game where you need to swap numbers in the shuffled square.");
		System.out.println("Please enter an odd integer: ");
		int n = num.nextInt();
		System.out.println("Original n*n square: ");
		int x = 0, y =((n+1) / 2)-1;
		//create the matrix of 0's
		int[][] matrix = new int[n][n];
		for (int i = 0; i < n; i++) { 
			for (int j = 0; j < n; j++) { 
				matrix[i][j] = 0;
			}
		}
		matrix[x][y] = 1;
		//algorithm
		for (int i = 2; i <= Math.pow(n,2); i++){
			if ((x == 0) && (y == 0)){
				x = 2;
				y = 1;
			}
			else{
				if(x <= 0){
					x = n;
				}

				if(y <= 0){
					y = n;
				}
			}
			if (matrix[x-1][y-1] == 0){
				x--;
				y--;
			}
			else{
					x++;
			}
		
		matrix[x][y] = i;
		}
	for (int i = 0; i < n; i++) { 
			for (int j = 0; j < n; j++) { 
				System.out.print(matrix[i][j] + " ");
			}
			System.out.println(" ");
		} 
	return matrix;
	}
}